﻿using AiInterviewAssistant.AutoVoice;
using AiInterviewAssistant.Privacy;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Tesseract;
using MessageBox = System.Windows.MessageBox;
using Microsoft.Win32;

namespace AiInterviewAssistant
{
    public partial class MainWindow : Window
    {

        // =========================================================
        // SCREENSHOT
        // =========================================================

        private Bitmap _currentScreenshot;


        // =========================================================
        // CONVERSATION
        // =========================================================

        private List<object> conversationHistory =
            new List<object>();


        // =========================================================
        // AI GENERATION
        // =========================================================

        private bool isGenerating = false;

        private CancellationTokenSource cancellationTokenSource;

        private string latestAiText = "";


        // =========================================================
        // AI TYPING ANIMATION
        // =========================================================

        private System.Windows.Threading.DispatcherTimer aiTypingTimer;

        private Border aiTypingBubble;

        private string aiTargetText = "";

        private int aiDisplayedLength = 0;


        // =========================================================
        // OCR
        // =========================================================

        private TesseractEngine ocrEngine;


        // =========================================================
        // ONLINE TEST
        // =========================================================

        private bool isOnlineTestMode = false;

        private bool isCapturingOnlineTestQuestion = false;

        private readonly object onlineCaptureLock =
            new object();

        private int onlineTestCaptureRunning = 0;


        // =========================================================
        // VISION REQUEST STATE
        // =========================================================

        private int visionRequestRunning = 0;

        // =========================================================
        // CLIPBOARD QUESTION
        // =========================================================

        private bool _clipboardQuestionAvailable = false;

        // =========================================================
        // SETTINGS
        // =========================================================

        private SettingsManager settingsManager;

        private AppSettings currentSettings;

        // =========================================================
        // PRIVACY
        // =========================================================

        private PrivacyManager _privacyManager;


        // =========================================================
        // SCREEN CAPTURE HIDE STATE
        // =========================================================

        private bool _hideFromCapture = true;


        // =========================================================
        // CURRENT SETTINGS WINDOW
        // =========================================================

        private SettingsWindow _currentSettingsWindow;


        // =========================================================
        // PRIVACY INITIALIZATION
        // =========================================================

        private bool _initializingPrivacy = true;


        // =========================================================
        // INTERVIEW SESSION
        // =========================================================

        private InterviewSessionLogger _interviewSessionLogger;

        private readonly AutoVoiceManager _autoVoiceManager;

        private bool _recordInterview = false;

        // =========================================================
        // CONSTRUCTOR
        // =========================================================

        public MainWindow()
        {
            InitializeComponent();

            _autoVoiceManager =
                new AutoVoiceManager(
                    Dispatcher,
                    () => isVoiceRecording,
                    () => voiceStopping,

                    // Prepare queue/cycle
                    () => PrepareVoiceCycleForNewRecording(),

                    // Start current voice cycle
                    () => StartVoiceCycleFromCurrentCapture(),

                    // Stop current voice cycle only
                    () => FinalizeVoiceCycleOnly(),

                    // Start continuous Wasapi capture
                    () => StartContinuousVoiceCapture(),

                    // Stop continuous Wasapi capture
                    () => StopContinuousVoiceCapture());

            // =====================================================
            // INTERVIEW SESSION LOGGER
            // =====================================================

            _interviewSessionLogger = new InterviewSessionLogger(
                () => _recordInterview);

            ChatScrollViewer.PreviewMouseWheel +=
                ChatScrollViewer_PreviewMouseWheel;


            // =====================================================
            // PRIVACY MANAGER
            // =====================================================

            _privacyManager =
                new PrivacyManager(this);


            // =====================================================
            // REGISTER MAIN WINDOW
            // =====================================================

            AppearanceManager.RegisterWindow(this);


            // =====================================================
            // SETTINGS MANAGER
            // =====================================================

            settingsManager =
                new SettingsManager(this);


            // =====================================================
            // LOAD SETTINGS
            // =====================================================

            currentSettings =
                SettingsService.Load()
                ?? new AppSettings();

            // Restore the saved resume filename/link on startup.
            UpdateResumeFileLink();

            // =====================================================
            // APPLY APPEARANCE
            // =====================================================

            AppearanceManager.Apply(
                this,
                currentSettings);


            // =====================================================
            // INITIAL STEALTH STATE
            // =====================================================

            _hideFromCapture =
                ScreenCaptureProtection.IsEnabled;

            if (HideToggleButton != null)
            {
                HideToggleButton.IsChecked =
                    _hideFromCapture;
            }


            // =====================================================
            // CLEAR CONVERSATION
            // =====================================================

            ClearConversation();


            //// =====================================================
            //// DEFAULT AI MESSAGE
            //// =====================================================

            //AddAIMessage(
            //    "Hello! I'm ready to help with your interview. Ask me any .NET, C#, SQL, System Design, or coding question."
            //);


            // =====================================================
            // WINDOW EVENTS
            // =====================================================

            MouseLeftButtonDown +=
                MainWindow_MouseLeftButtonDown;

            SourceInitialized +=
                MainWindow_SourceInitialized;

            Closed +=
                MainWindow_Closed;

            IsVisibleChanged +=
                MainWindow_ClipboardVisibilityChanged;

        }

        private void RecordInterviewCheckBox_Checked(
    object sender,
    RoutedEventArgs e)
        {
            if (currentSettings == null)
                return;

            _recordInterview = true;
        }

        private void RecordInterviewCheckBox_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            if (currentSettings == null)
                return;

            _recordInterview = false;
        }


        // =========================================================
        // CHAT MOUSE WHEEL SCROLL
        // =========================================================

        private void ChatScrollViewer_PreviewMouseWheel(
            object sender,
            MouseWheelEventArgs e)
        {
            try
            {
                if (ChatScrollViewer == null ||
                    !ChatScrollViewer.IsLoaded)
                    return;

                const double SCROLL_DISTANCE = 70.0;

                double currentOffset =
                    ChatScrollViewer.VerticalOffset;

                double targetOffset =
                    currentOffset +
                    (e.Delta > 0
                        ? -SCROLL_DISTANCE
                        : SCROLL_DISTANCE);

                targetOffset =
                    Math.Max(
                        0,
                        Math.Min(
                            targetOffset,
                            ChatScrollViewer.ScrollableHeight));

                StartSmoothChatScroll(
                    targetOffset);

                e.Handled = true;
            }
            catch
            {
            }
        }


        // =========================================================
        // SOURCE INITIALIZED
        // =========================================================

        private void MainWindow_SourceInitialized(
            object sender,
            EventArgs e)
        {
            WindowBehaviorManager.Attach(this);

            try
            {
                HotKeysRegister.Register(
                    this,

                    // =================================================
                    // CTRL + \
                    // =================================================

                    () =>
                    {
                        try
                        {
                            // =============================================
                            // SETTINGS WINDOW OPEN
                            // =============================================

                            if (settingsManager != null &&
                                settingsManager.IsSettingsVisible)
                            {
                                return;
                            }


                            // =============================================
                            // TOGGLE MAIN WINDOW
                            // =============================================

                            if (IsVisible)
                            {
                                Hide();

                                try
                                {
                                    StopWindowMoveAnimation();
                                }
                                catch
                                {
                                }

                                return;
                            }


                            // =============================================
                            // SHOW MAIN WINDOW
                            // =============================================

                            Show();

                            WindowState =
                                WindowState.Normal;

                            Topmost = true;

                            Activate();

                            Focus();
                        }
                        catch
                        {
                        }
                    },


                   // =================================================
                   // CTRL + LEFT
                   // =================================================

                   () =>
                   {
                       try
                       {
                           if (settingsManager != null &&
                                settingsManager.IsSettingsVisible)
                           {
                               SettingsWindow settingsWindow =
                                   settingsManager.CurrentSettingsWindow;

                               if (settingsWindow != null &&
                                   settingsWindow.IsVisible)
                               {
                                   WindowBehaviorManager.MoveSettingsWindow(
                                       settingsWindow,
                                       HotKeysRegister.MOVE_LEFT_HOTKEY_ID);

                                   return;
                               }
                           }

                           WindowBehaviorManager.MoveMainWindow(
                               this,
                               HotKeysRegister.MOVE_LEFT_HOTKEY_ID);
                       }
                       catch
                       {
                       }
                   },


                    // =================================================
                    // CTRL + RIGHT
                    // =================================================

                    () =>
                    {
                        try
                        {

                            if (settingsManager != null &&
                                    settingsManager.IsSettingsVisible)
                            {
                                SettingsWindow settingsWindow =
                                    settingsManager.CurrentSettingsWindow;

                                if (settingsWindow != null &&
                                    settingsWindow.IsVisible)
                                {
                                    WindowBehaviorManager.MoveSettingsWindow(
                                        settingsWindow,
                                        HotKeysRegister.MOVE_RIGHT_HOTKEY_ID);

                                    return;
                                }
                            }

                            WindowBehaviorManager.MoveMainWindow(
                               this,
                               HotKeysRegister.MOVE_RIGHT_HOTKEY_ID);
                        }
                        catch
                        {
                        }
                    },


                    // =================================================
                    // CTRL + UP
                    // =================================================

                    () =>
                    {
                        try
                        {

                            if (settingsManager != null &&
                                    settingsManager.IsSettingsVisible)
                            {
                                SettingsWindow settingsWindow =
                                    settingsManager.CurrentSettingsWindow;

                                if (settingsWindow != null &&
                                    settingsWindow.IsVisible)
                                {
                                    WindowBehaviorManager.MoveSettingsWindow(
                                        settingsWindow,
                                        HotKeysRegister.MOVE_UP_HOTKEY_ID);

                                    return;
                                }
                            }

                            WindowBehaviorManager.MoveMainWindow(
                                this,
                                HotKeysRegister.MOVE_UP_HOTKEY_ID);
                        }
                        catch
                        {
                        }
                    },


                   // =================================================
                   // CTRL + DOWN
                   // =================================================

                   () =>
                   {
                       try
                       {

                           if (settingsManager != null &&
                                settingsManager.IsSettingsVisible)
                           {
                               SettingsWindow settingsWindow =
                                   settingsManager.CurrentSettingsWindow;

                               if (settingsWindow != null &&
                                   settingsWindow.IsVisible)
                               {
                                   WindowBehaviorManager.MoveSettingsWindow(
                                       settingsWindow,
                                       HotKeysRegister.MOVE_DOWN_HOTKEY_ID);

                                   return;
                               }
                           }

                           WindowBehaviorManager.MoveMainWindow(
                               this,
                               HotKeysRegister.MOVE_DOWN_HOTKEY_ID);
                       }
                       catch
                       {
                       }
                   },


                    // =================================================
                    // ALT + UP
                    // =================================================

                    () =>
                    {
                        try
                        {
                            ScrollChatWindow(
                                HotKeysRegister
                                    .SCROLL_UP_HOTKEY_ID);
                        }
                        catch
                        {
                        }
                    },


                    // =================================================
                    // ALT + DOWN
                    // =================================================

                    () =>
                    {
                        try
                        {
                            ScrollChatWindow(
                                HotKeysRegister
                                    .SCROLL_DOWN_HOTKEY_ID);
                        }
                        catch
                        {
                        }
                    },


                    // =================================================
                    // ESC
                    // =================================================

                    () =>
                    {
                        try
                        {
                            if (settingsManager != null &&
                                settingsManager.IsSettingsVisible)
                            {
                                settingsManager.CloseSettings();
                                return;
                            }

                            if (IsVisible)
                            {
                                Close();
                            }
                        }
                        catch
                        {
                        }
                    },


                    //// =================================================
                    //// SPACE
                    //// =================================================

                    //() =>
                    //{
                    //    try
                    //    {
                    //        if (!IsVoiceInputEnabled()) 
                    //            return; 

                    //        if (voiceRecorder == null) 
                    //        { 
                    //            StartVoiceRecording();
                    //        } 
                    //        else 
                    //        { 
                    //            StopVoiceRecording(); 
                    //        }
                    //    }
                    //    catch
                    //    {
                    //    }
                    //},

                    // =================================================
                    // SPACE
                    // =================================================

                    () =>
                    {
                        try
                        {
                            ToggleVoiceRecording();
                        }
                        catch
                        {
                        }
                    },


                    // ALT + ENTER
                    // VISION AI / MCQ
                    () =>
                    {
                        try
                        {
                            HandleAltEnterAsync();
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(
                                "ALT + ENTER ERROR: " +
                                ex);
                        }
                    },

                    // =================================================
                    // SHIFT + ENTER
                    // CODING QUESTION
                    // =================================================

                    () =>
                    {
                        try
                        {
                            _ = HandleShiftEnterAsync();
                        }
                        catch
                        {
                        }
                    },


                    // =================================================
                    // CTRL + ENTER
                    // =================================================

                    () =>
                    {
                        try
                        {
                            _ = SendQuestion();
                        }
                        catch
                        {
                        }
                    },


                    // =================================================
                    // CTRL + SHIFT + \
                    // SETTINGS
                    // =================================================

                    () =>
                    {
                        try
                        {
                            ToggleSettingsWindow();
                        }
                        catch
                        {
                        }
                    },


                    // =================================================
                    // MESSAGE MODE
                    // =================================================

                    () =>
                    {
                        try
                        {
                            if (MessageModeButton == null)
                                return;

                            MessageModeButton.IsChecked =
                                !MessageModeButton.IsChecked;
                        }
                        catch
                        {
                        }
                    },

                    // =================================================
                    // CTRL + SHIFT + A
                    // AUTO VOICE ON / OFF
                    // =================================================

                    () =>
                    {
                        try
                        {
                            if (AutoVoiceButton == null)
                                return;

                            AutoVoiceButton.IsChecked =
                                !AutoVoiceButton.IsChecked;
                        }
                        catch
                        {
                        }
                    },

                     // =================================================
                     // CLEAR CHAT
                     // CTRL + SHIFT + BACKSPACE
                     // =================================================

                     () =>
                     {
                         try
                         {
                             if (isGenerating &&
                                 cancellationTokenSource != null)
                             {
                                 cancellationTokenSource.Cancel();
                             }

                             ClearConversation();
                         }
                         catch
                         {
                         }
                     },

                    // =================================================
                    // CTRL + C
                    // CLIPBOARD QUESTION
                    // =================================================

                    () =>
                    {
                        CaptureClipboardQuestionAfterCopy();
                    }

                );


                // =====================================================
                // PRIVACY INITIALIZATION
                // =====================================================

                if (_privacyManager != null)
                {
                    // =================================================
                    // READ STEALTH STATE FROM APP.CONFIG
                    // =================================================

                    bool stealthEnabled =
                        ScreenCaptureProtection.IsEnabled;


                    _hideFromCapture =
                        stealthEnabled;


                    if (HideToggleButton != null)
                    {
                        HideToggleButton.IsChecked =
                            stealthEnabled;
                    }


                    // =================================================
                    // STEALTH MODE ON
                    // =================================================

                    if (stealthEnabled)
                    {
                        bool result =
                            _privacyManager
                                .EnableScreenCaptureProtection();


                        if (!result)
                        {
                            _hideFromCapture = false;

                            if (HideToggleButton != null)
                            {
                                HideToggleButton.IsChecked =
                                    false;
                            }

                            ScreenCaptureProtection
                                .ApplyToAllWindows(false);
                        }
                        else
                        {
                            ScreenCaptureProtection
                                .ApplyToAllWindows(true);

                            ApplyPrivacyToSettingsWindow();
                        }
                    }


                    // =================================================
                    // STEALTH MODE OFF
                    // =================================================

                    else
                    {
                        _privacyManager
                            .DisableScreenCaptureProtection();


                        ScreenCaptureProtection
                            .ApplyToAllWindows(false);


                        ApplyPrivacyToSettingsWindow();
                    }
                }
            }
            catch
            {
                _hideFromCapture = false;

                if (HideToggleButton != null)
                {
                    HideToggleButton.IsChecked =
                        false;
                }
            }
            finally
            {
                _initializingPrivacy = false;
            }
        }

        private async Task HandleShiftEnterAsync()
        {
            try
            {
                Border codingQuestionBubble = null;

                await Dispatcher.InvokeAsync(() =>
                {
                    codingQuestionBubble =
                        AddUserMessage(
                            "🔍 Reading question...");
                });

                // =========================================================
                // SHIFT + ENTER
                // CODING QUESTION ONLY
                // =========================================================

                bool success =
                    await TryProcessCodingQuestionAsync();

                // =========================================================
                // REMOVE TEMPORARY "READING QUESTION..." MESSAGE
                // =========================================================

                await Dispatcher.InvokeAsync(() =>
                {
                    if (codingQuestionBubble != null)
                    {
                        if (codingQuestionBubble.Parent is Panel parent)
                        {
                            parent.Children.Remove(
                                codingQuestionBubble);
                        }

                        codingQuestionBubble = null;
                    }
                });

                if (!success)
                {
                    Debug.WriteLine(
                        "SHIFT + ENTER: Coding question processing failed.");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(
                    "SHIFT + ENTER ERROR: " +
                    ex);
            }
        }


        // =========================================================
        // ALT + ENTER ENTRY POINT
        // =========================================================

        private async void HandleAltEnterAsync()
        {
            try
            {
                // =========================================================
                // 1. CHECK FOR FRESH COPIED QUESTION
                // =========================================================
                //
                // If interviewer question was copied using CTRL+C,
                // process the clipboard text directly.
                //
                // IMPORTANT:
                // Do NOT show "🔍 Reading question..." for copied questions.
                //
                // =========================================================

                string clipboardQuestion =
                    ConsumeClipboardQuestion();

                if (!string.IsNullOrWhiteSpace(clipboardQuestion))
                {
                    Debug.WriteLine(
                        "ALT + ENTER: Using copied clipboard question.");

                    await SendQuestion(
                        clipboardQuestion);

                    return;
                }


                // =========================================================
                // 2. NO COPIED QUESTION
                //
                // Continue with the existing Vision / MCQ flow.
                // =========================================================

                if (!TryStartVisionRequest())
                {
                    return;
                }

                try
                {
                    await RunVisionAiFromScreenAsync();
                }
                finally
                {
                    FinishVisionRequest();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(
                    "ALT + ENTER ERROR: " +
                    ex);
            }
        }



        // =========================================================
        // CLIPBOARD QUESTION CAPTURE
        // =========================================================

        private void CaptureClipboardQuestionAfterCopy()
        {
            try
            {
                if (!IsVisible)
                    return;

                // Only remember that a fresh Ctrl+C happened
                // while the assistant was visible.
                _clipboardQuestionAvailable = true;

                Debug.WriteLine(
                    "CTRL+C DETECTED WHILE MAIN WINDOW IS VISIBLE.");
            }
            catch
            {
                _clipboardQuestionAvailable = false;
            }
        }

        private void ClearClipboardQuestionState()
        {
            _clipboardQuestionAvailable = false;
        }

        private void MainWindow_ClipboardVisibilityChanged(
            object sender,
            DependencyPropertyChangedEventArgs e)
        {
            try
            {
                if (!IsVisible)
                {
                    // A Ctrl+C captured before Hide must never
                    // become valid after the assistant is shown again.
                    ClearClipboardQuestionState();
                }
            }
            catch
            {
            }
        }


        // =========================================================
        // ACTIVE WINDOW MOVEMENT
        // =========================================================

        private void MoveActiveWindow1(
            int hotkeyId)
        {
            try
            {
                if (settingsManager != null &&
                    settingsManager.IsSettingsVisible)
                {
                    SettingsWindow settingsWindow =
                        settingsManager.CurrentSettingsWindow;

                    if (settingsWindow != null &&
                        settingsWindow.IsVisible)
                    {
                        MoveSettingsWindow(
                            settingsWindow,
                            hotkeyId);

                        return;
                    }
                }

                MoveMainWindow(
                    hotkeyId);
            }
            catch
            {
            }
        }


        // =========================================================
        // MOVE SETTINGS WINDOW
        // =========================================================

        private void MoveSettingsWindow(
            SettingsWindow settingsWindow,
            int hotkeyId)
        {
            try
            {
                if (settingsWindow == null ||
                    !settingsWindow.IsVisible)
                    return;

                if (settingsWindow.WindowState ==
                    WindowState.Minimized)
                    return;

                double windowWidth =
                    settingsWindow.ActualWidth;

                double windowHeight =
                    settingsWindow.ActualHeight;

                if (double.IsNaN(windowWidth) ||
                    windowWidth <= 0)
                {
                    windowWidth =
                        settingsWindow.Width;
                }

                if (double.IsNaN(windowHeight) ||
                    windowHeight <= 0)
                {
                    windowHeight =
                        settingsWindow.Height;
                }

                double currentLeft =
                    settingsWindow.Left;

                double currentTop =
                    settingsWindow.Top;

                if (double.IsNaN(currentLeft))
                    currentLeft = 0;

                if (double.IsNaN(currentTop))
                    currentTop = 0;

                double targetLeft =
                    currentLeft;

                double targetTop =
                    currentTop;


                switch (hotkeyId)
                {
                    case HotKeysRegister
                        .MOVE_LEFT_HOTKEY_ID:

                        targetLeft -=
                            WINDOW_MOVE_DISTANCE;

                        break;


                    case HotKeysRegister
                        .MOVE_RIGHT_HOTKEY_ID:

                        targetLeft +=
                            WINDOW_MOVE_DISTANCE;

                        break;


                    case HotKeysRegister
                        .MOVE_UP_HOTKEY_ID:

                        targetTop -=
                            WINDOW_MOVE_DISTANCE;

                        break;


                    case HotKeysRegister
                        .MOVE_DOWN_HOTKEY_ID:

                        targetTop +=
                            WINDOW_MOVE_DISTANCE;

                        break;


                    default:
                        return;
                }


                System.Windows.Forms.Screen screen =
                    System.Windows.Forms.Screen
                        .FromHandle(
                            new WindowInteropHelper(
                                settingsWindow).Handle);


                System.Drawing.Rectangle workArea =
                    screen.WorkingArea;


                double screenLeft =
                    workArea.Left;

                double screenTop =
                    workArea.Top;

                double screenRight =
                    workArea.Right;

                double screenBottom =
                    workArea.Bottom;


                double maxLeft =
                    screenRight - windowWidth;

                double maxTop =
                    screenBottom - windowHeight;


                if (maxLeft < screenLeft)
                    maxLeft = screenLeft;

                if (maxTop < screenTop)
                    maxTop = screenTop;


                targetLeft =
                    Math.Max(
                        screenLeft,
                        Math.Min(
                            targetLeft,
                            maxLeft));


                targetTop =
                    Math.Max(
                        screenTop,
                        Math.Min(
                            targetTop,
                            maxTop));


                settingsWindow.Left =
                    targetLeft;

                settingsWindow.Top =
                    targetTop;
            }
            catch
            {
            }
        }


        // =========================================================
        // OCR INITIALIZATION
        // =========================================================

        private void InitializeOCR()
        {
            try
            {
                string tessDataPath =
                    Path.Combine(
                        AppDomain.CurrentDomain.BaseDirectory,
                        "tessdata");

                ocrEngine =
                    new TesseractEngine(
                        tessDataPath,
                        "eng",
                        EngineMode.Default);
            }
            catch (Exception ex)
            {
                AppMessage.Show(
                    "OCR initialization error:\n\n" +
                    ex.Message);
            }
        }


        // =========================================================
        // HIDE
        // =========================================================

        private void HideToggleButton_Checked(
            object sender,
            RoutedEventArgs e)
        {
            if (_initializingPrivacy)
                return;

            try
            {
                // =====================================================
                // STEALTH MODE IS CONFIGURED IN APP.CONFIG
                // =====================================================

                if (!ScreenCaptureProtection.IsEnabled)
                {
                    if (HideToggleButton != null)
                    {
                        HideToggleButton.IsChecked =
                            false;
                    }

                    return;
                }


                if (_privacyManager == null)
                    return;


                bool result =
                    _privacyManager
                        .EnableScreenCaptureProtection();


                if (!result)
                {
                    _hideFromCapture = false;

                    if (HideToggleButton != null)
                    {
                        HideToggleButton.IsChecked =
                            false;
                    }

                    AppMessage.Show(
                        "Unable to enable screen capture protection.");

                    return;
                }


                _hideFromCapture = true;


                // =====================================================
                // APPLY PRIVACY TO COMPLETE APPLICATION
                // =====================================================

                ScreenCaptureProtection
                    .ApplyToAllWindows(true);

                ApplyPrivacyToSettingsWindow();
            }
            catch (Exception ex)
            {
                _hideFromCapture = false;

                if (HideToggleButton != null)
                {
                    HideToggleButton.IsChecked =
                        false;
                }

                AppMessage.Show(
                    "Hide mode error:\n\n" +
                    ex.Message);
            }
        }


        // =========================================================
        // SHOW
        // =========================================================

        private void HideToggleButton_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            if (_initializingPrivacy)
                return;

            try
            {
                _hideFromCapture = false;


                if (_privacyManager != null)
                {
                    _privacyManager
                        .DisableScreenCaptureProtection();
                }


                // =====================================================
                // RESTORE PRIVACY/UI FOR COMPLETE APPLICATION
                // =====================================================

                ScreenCaptureProtection
                    .ApplyToAllWindows(false);

                ApplyPrivacyToSettingsWindow();
            }
            catch (Exception ex)
            {
                AppMessage.Show(
                    "Show mode error:\n\n" +
                    ex.Message);
            }
        }


        // =========================================================
        // PUBLIC HIDE STATE
        // =========================================================

        public bool IsHideFromCaptureEnabled
        {
            get
            {
                return _hideFromCapture;
            }
        }


        // =========================================================
        // REGISTER SETTINGS WINDOW
        // =========================================================

        public void RegisterSettingsWindow(
            SettingsWindow settingsWindow)
        {
            try
            {
                _currentSettingsWindow =
                    settingsWindow;

                ApplyPrivacyToSettingsWindow();
            }
            catch
            {
            }
        }


        // =========================================================
        // UNREGISTER SETTINGS WINDOW
        // =========================================================

        public void UnregisterSettingsWindow(
            SettingsWindow settingsWindow)
        {
            try
            {
                if (_currentSettingsWindow ==
                    settingsWindow)
                {
                    _currentSettingsWindow =
                        null;
                }
            }
            catch
            {
            }
        }


        // =========================================================
        // APPLY PRIVACY
        // =========================================================

        private void ApplyPrivacyToSettingsWindow()
        {
            try
            {
                if (_currentSettingsWindow == null)
                    return;

                if (!_currentSettingsWindow.IsVisible)
                    return;

                _currentSettingsWindow
                    .ApplyScreenCaptureProtection(
                        _hideFromCapture);
            }
            catch
            {
            }
        }


        // =========================================================
        // REFRESH PRIVACY
        // =========================================================

        public void RefreshPrivacyProtection()
        {
            try
            {
                if (_privacyManager == null)
                    return;


                if (_hideFromCapture)
                {
                    _privacyManager
                        .EnableScreenCaptureProtection();


                    ScreenCaptureProtection
                        .ApplyToAllWindows(true);
                }
                else
                {
                    _privacyManager
                        .DisableScreenCaptureProtection();


                    ScreenCaptureProtection
                        .ApplyToAllWindows(false);
                }


                ApplyPrivacyToSettingsWindow();
            }
            catch
            {
            }
        }


        // =========================================================
        // SETTINGS BUTTON
        // =========================================================

        private void SettingsButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                settingsManager.ShowSettings();

                Dispatcher.BeginInvoke(
                    new Action(
                        ApplyPrivacyToSettingsWindow));
            }
            catch (Exception ex)
            {
                AppMessage.Show(
                    "Settings window error:\n\n" +
                    ex.Message);
            }
        }


        // =========================================================
        // TOGGLE SETTINGS
        // =========================================================

        private void ToggleSettingsWindow()
        {
            try
            {
                if (settingsManager == null)
                    return;


                if (settingsManager.IsSettingsVisible)
                {
                    settingsManager.CloseSettings();
                    return;
                }


                if (!IsVisible)
                    return;


                settingsManager.ShowSettings();


                Dispatcher.BeginInvoke(
                    new Action(
                        ApplyPrivacyToSettingsWindow));
            }
            catch (Exception ex)
            {
                AppMessage.Show(
                    "Settings window error:\n\n" +
                    ex.Message);
            }
        }


        // =========================================================
        // REFRESH GENERAL SETTINGS
        // =========================================================

        public void RefreshGeneralSettings()
        {
            try
            {
                currentSettings =
                    SettingsService.Load()
                    ?? new AppSettings();

                UpdateResumeFileLink();
            }
            catch (Exception ex)
            {
                AppMessage.Show(
                    "General settings refresh error:\n\n" +
                    ex.Message);
            }
        }


        // =========================================================
        // WINDOW DRAG
        // =========================================================

        private void MainWindow_MouseLeftButtonDown(
            object sender,
            MouseButtonEventArgs e)
        {
            try
            {
                if (e.ChangedButton ==
                    MouseButton.Left)
                {
                    DragMove();
                }
            }
            catch
            {
            }
        }


        // =========================================================
        // EXIT
        // =========================================================

        private void ExitButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                System.Windows.Application.Current
                    ?.Shutdown();
            }
            catch
            {
            }
        }


        // =========================================================
        // MESSAGE MODE ON
        // =========================================================

        private void MessageModeButton_Checked(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                if (TextInputPanel != null)
                {
                    TextInputPanel.Visibility =
                        Visibility.Visible;
                }


                Dispatcher.BeginInvoke(
                    new Action(() =>
                    {
                        try
                        {
                            if (QuestionTextBox == null)
                                return;


                            Activate();


                            QuestionTextBox.Focus();


                            Keyboard.Focus(
                                QuestionTextBox);


                            QuestionTextBox.CaretIndex =
                                QuestionTextBox.Text.Length;
                        }
                        catch
                        {
                        }
                    }),
                    DispatcherPriority.Input);
            }
            catch
            {
            }
        }


        // =========================================================
        // MESSAGE MODE OFF
        // =========================================================

        private void MessageModeButton_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                if (TextInputPanel != null)
                {
                    TextInputPanel.Visibility =
                        Visibility.Collapsed;
                }
            }
            catch
            {
            }
        }


        // =========================================================
        // CLEAR CHAT HOTKEY
        // =========================================================

        private void ClearChatFromHotkey()
        {
            try
            {
                if (isGenerating &&
                    cancellationTokenSource != null)
                {
                    cancellationTokenSource.Cancel();
                }

                ClearConversation();
            }
            catch
            {
            }
        }


        private void AddResumeButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Select Resume",
                Filter =
                    "Resume Files (*.pdf;*.docx;*.txt)|*.pdf;*.docx;*.txt|" +
                    "PDF Files (*.pdf)|*.pdf|" +
                    "Word Documents (*.docx)|*.docx|" +
                    "Text Files (*.txt)|*.txt",
                Multiselect = false,
                CheckFileExists = true
            };

            // Cancel must leave the previously selected resume unchanged.
            if (dialog.ShowDialog() != true)
                return;

            string filePath = dialog.FileName;
            string previousText = currentSettings?.ResumeText ?? string.Empty;
            string previousPath = currentSettings?.ResumeFilePath ?? string.Empty;

            try
            {
                // Uses the same supported file formats as the Resume tab.
                string resumeText = ResumeFileService.ExtractText(filePath);

                if (string.IsNullOrWhiteSpace(resumeText))
                {
                    MessageBox.Show(
                        "Could not extract any text from the selected resume.",
                        "Resume",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                if (currentSettings == null)
                    currentSettings = new AppSettings();

                currentSettings.ResumeText = resumeText.Trim();
                currentSettings.ResumeFilePath = filePath;

                // Save automatically. Roll back in-memory values if saving fails.
                bool saved;
                try
                {
                    saved = SettingsService.Save(currentSettings);
                }
                catch
                {
                    currentSettings.ResumeText = previousText;
                    currentSettings.ResumeFilePath = previousPath;
                    throw;
                }

                if (!saved)
                {
                    currentSettings.ResumeText = previousText;
                    currentSettings.ResumeFilePath = previousPath;

                    MessageBox.Show(
                        "Resume settings could not be saved. Your previous resume settings have been preserved.",
                        "Resume",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                    return;
                }

                UpdateResumeFileLink();
            }
            catch (Exception ex)
            {
                if (currentSettings != null)
                {
                    currentSettings.ResumeText = previousText;
                    currentSettings.ResumeFilePath = previousPath;
                }

                MessageBox.Show(
                    "Unable to import the resume. Your previous resume settings have been preserved.\n\n" +
                    ex.Message,
                    "Resume",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void UpdateResumeFileLink()
        {
            string filePath = currentSettings?.ResumeFilePath;

            bool fileExists =
                !string.IsNullOrWhiteSpace(filePath) &&
                File.Exists(filePath);

            ResumeFileLinkButton.Content =
                fileExists ? Path.GetFileName(filePath) : string.Empty;

            ResumeFileLinkButton.ToolTip =
                fileExists ? filePath : "No resume file selected";

            ResumeFileLinkButton.Visibility =
                fileExists ? Visibility.Visible : Visibility.Collapsed;
        }

        private void ResumeFileLinkButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                string filePath = currentSettings?.ResumeFilePath;

                if (string.IsNullOrWhiteSpace(filePath) ||
                    !File.Exists(filePath))
                {
                    MessageBox.Show(
                        "The original resume file could not be found. " +
                        "Please select it again.",
                        "Resume",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return;
                }

                Process.Start(new ProcessStartInfo
                {
                    FileName = filePath,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to open the resume.\n\n" + ex.Message,
                    "Resume",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

    }
}